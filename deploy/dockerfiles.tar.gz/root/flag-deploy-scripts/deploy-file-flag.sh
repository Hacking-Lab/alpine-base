#!/usr/bin/with-contenv bash

echo "put your commands to deploy the file based flag here"
echo "the /goldnugget/*.gn contains the flag"

