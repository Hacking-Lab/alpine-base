#!/usr/bin/with-contenv bash

echo "put your commands to deploy the env based flag here"
echo "the variable \$GOLDNUGGET contains the dynamic flag"
